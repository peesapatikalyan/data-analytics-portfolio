# sentiment_analysis_script.py

import pandas as pd
import spacy
from textblob import TextBlob

# Load data
df = pd.read_csv('data/amazon_escalation_sample.csv')

# Load spaCy model
nlp = spacy.load("en_core_web_sm")

# Define function to extract named entities and polarity
def analyze_text(text):
    doc = nlp(text)
    entities = [(ent.text, ent.label_) for ent in doc.ents]
    polarity = TextBlob(text).sentiment.polarity
    return entities, polarity

# Apply function
df['entities'] = df['escalation_text'].apply(lambda x: analyze_text(x)[0])
df['text_polarity'] = df['escalation_text'].apply(lambda x: analyze_text(x)[1])

# Save output
df.to_csv('outputs/sentiment_analysis_results.csv', index=False)